class Usuario {
    constructor(nombre, apellido, libros, mascotas){
        this.nombre = nombre,
        this.apellido = apellido,
        this.libros = libros,
        this.mascotas = mascotas
    };

    getFullName = () => `${this.nombre}` + ` ${this.apellido}`;

    addMascota = (mascota) => {
        this.mascotas.push(mascota);
    };

    countMascotas = () => this.mascotas.length;

    addBook = (nombreLibro, autorLibro) => {
        this.libros.push({
            nombre: nombreLibro,
            autor: autorLibro
        })
    };

    getBooksNames = () => this.libros.map((libro) => libro.nombre);

}